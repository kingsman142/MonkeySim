public class Banana {

    public Banana() {

    }

}
